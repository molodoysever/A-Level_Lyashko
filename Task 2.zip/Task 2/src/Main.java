import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Width");
        int width = scanner.nextInt();
        System.out.println("Heigh");
        int heigh = scanner.nextInt();
        int area = (width * heigh)/2;
        System.out.println("Area = " + area);
    }
}

class Task2 {
    public static void main(String[] args) {
        Random random = new Random();
        int a = random.nextInt();
        System.out.println("Mean 1 = " +a);
        int b = random.nextInt();
        System.out.println("Mean 2 = " +b);
        int c = random.nextInt();
        System.out.println("Mean 3 = " +c);
        if (a < b && a < c) {
            System.out.println("Smallest = " + a);
        } else if (b < c && b < a) {
            System.out.println("Smallest = " + b);
        } else {
            System.out.println("Smallest = " + c);
        }
    }
}

class Task3 {
    public static void main(String[] args) {
        Random random = new Random();
        int a = random.nextInt();
        System.out.println("Generated number = " + a);
        if (a % 2 == 0 )
            System.out.println(a + " = is even");
        else
            System.out.println(a + " = is uneven");
    }
}

class Task4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a number");
        int number;
        number = scanner.nextInt();
        if (number < 0) {
            System.out.println("ERROR! Enter positive number");
        } else {
            System.out.print("Binary = " + Integer.toBinaryString(number));
        }
    }
}